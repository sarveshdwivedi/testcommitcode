import { SubmissionModel, ISubmission } from '../models/submission';
import { uuidv1 } from 'uuid/v1';

class Submission {
	public post(req, res, next) {
		//implement logic to save to mongoose here

		var submissionData = req.body;
		var UniqueId;
		var dbFormPageStep;
		if (!submissionData.UniqueId) {
			UniqueId = uuidv1();
		}
		else {
			UniqueId = submissionData.UniqueId;
		}

		SubmissionModel.findOne({
			$or: [
				{ 'UniqueId': UniqueId },
				{ 'UniqueNumber': UniqueId }
			]
		}, function (err, submission) {
			if (err) {
				res.json({ status: 201, message: err });
			} else {
				if (submission) {
					if (!submission.UniqueNumber) {
						var qstmno = submissionData.submission.submissionId
					} else {
						var qstmno = submission.UniqueNumber
					}

					UniqueId = submission.UniqueId
					var dbFormData = submission.value;
					var dbFormpageCompleted = submission.pageCompleted;
					for (var submissionKey in submissionData.submission) {
						for (var DBkey in dbFormData) {
							if (submissionKey == DBkey) {
								dbFormData[DBkey] = submissionData.submission[submissionKey];
							} else {
								dbFormData[submissionKey] = submissionData.submission[submissionKey];
							}
						}
					}

					var pageStep = 0;
					dbFormpageCompleted.forEach(element => {
						if (submissionData.step == element.pageNo) {
							pageStep++;
						}
					});


					if (pageStep == 0) {
						dbFormpageCompleted.push({ pageNo: submissionData.step, pageTitle: submissionData.pageTitle });
					}

					var Record = {
						UniqueId: UniqueId,
						UniqueNumber: qstmno,
						value: dbFormData,
						pageCompleted: dbFormpageCompleted
					}
					//console.log('Record==>', Record);
					SubmissionModel.update(
						{ UniqueId: UniqueId },
						Record,
						{
							upsert: true
						}, function (err, results: ISubmission) {
							if (err) {
								res.json({ error: err });
							} else {
								res.json({ statusCode: 200, message: "Submission object saved successfully", data: submissionData.submission, UniqueId: UniqueId })
							}
						}
					)

				} else {
					dbFormPageStep = { pageNo: submissionData.step, pageTitle: submissionData.pageTitle };
					var Record = {
						UniqueId: UniqueId,
						UniqueNumber: submissionData.submission.submissionId,
						value: submissionData.submission,
						pageCompleted: dbFormPageStep
					}

					SubmissionModel.update(
						{ UniqueId: UniqueId },
						Record,
						{
							upsert: true
						}, function (err, results: ISubmission) {
							if (err) {
								res.json({ error: err });
							} else {
								res.json({ statusCode: 200, message: "Submission saved successfully", data: submissionData.submission, UniqueId: UniqueId })
							}
						}
					)
				}
			}
		});
	}

	public get(req, res, next) {
		//implement logic to save to mongoose here
		//var SubmissionModel = new SubmissionModel();
		//console.log(req.query);
		var UniqueId = req.query.id;

		SubmissionModel.findOne({
			$or: [
				{ 'UniqueId': UniqueId },
				{ 'UniqueNumber': UniqueId }
			]
		}, function (err, submission) {
			if (err) {
				res.json({ status: 201, message: err });
			} else {
				console.log('submission==>', submission);
				res.json({ status: 200, message: "Submission object fetched successfully", data: submission });
			}
		});
	}

	
}

const post = new Submission().post;
const get = new Submission().get;
export { post, get };