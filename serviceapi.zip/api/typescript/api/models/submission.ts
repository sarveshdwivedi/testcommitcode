import * as mongoose from 'mongoose';

export interface ISubmission extends mongoose.Document {
	// model here
	_id: string, // Mongo ObjectId
	UniqueId: string,
	UniqueNumber: string,
	value: {},
	pageCompleted: [{
		pageNo: Number,
		pageTitle: String
	}]
	//etc
}

const schema = new mongoose.Schema({
	// schema model should match Document model
	UniqueId: { type: String },
	UniqueNumber:  { type: String },
	value: {},
	pageCompleted: [{
		pageNo: Number,
		pageTitle: String
	}]
	//etc
})

const SubmissionModel = mongoose.model<ISubmission>("submission", schema);
export { SubmissionModel };