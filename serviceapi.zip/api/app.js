'use strict';

var SwaggerExpress = require('swagger-express-mw');
var express = require('express');
var path = require('path');
var app = require('express')();
var config = require("./config/mongoConfig");
var mongoose = require('mongoose');
mongoose.connect("mongodb://" + config.username + ":" + config.password + "@" + config.host + ":" + config.port + "/" + config.database);

mongoose.set('debug', true);

module.exports = app; // for testing
app.use(express.static(path.join(__dirname, 'dist')));

var config = {
  appRoot: __dirname // required config
};


SwaggerExpress.create(config, function (err, swaggerExpress) {
  if (err) { throw err; }

  
  // All api requests
  app.use(function (req, res, next) {
    // CORS headers
    res.header("Access-Control-Allow-Origin", "*"); // restrict it to the required domain
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    // Set custom headers for CORS
    res.header('Access-Control-Allow-Headers', 'Content-type,Accept,X-Access-Token,X-Key,If-Modified-Since,Authorization');

    if (req.method == 'OPTIONS') {
      res.status(200).end();
    } else {
      next();
    }

  });
  
  // enable SwaggerUI
  app.use(swaggerExpress.runner.swaggerTools.swaggerUi());
  // install middleware
  swaggerExpress.register(app);

  var port = process.env.PORT || 4001;
  app.listen(port);

  if (swaggerExpress.runner.swagger.paths['/hello']) {
    console.log('try this:\ncurl http://127.0.0.1:' + port + '/hello?name=Scott');
  }
});
