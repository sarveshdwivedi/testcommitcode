"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var submission_1 = require("../models/submission");
var uuidv1 = require("uuid/v1");
var Submission = /** @class */ (function () {
    function Submission() {
    }
    Submission.prototype.post = function (req, res, next) {
        //implement logic to save to mongoose here
        var submissionData = req.body;
        var UniqueId;
        var dbFormPageStep;
        if (!submissionData.UniqueId) {
            UniqueId = uuidv1();
        }
        else {
            UniqueId = submissionData.UniqueId;
        }
        //console.log('submissionData.submissionId==>', submissionData.submissionId);
        submission_1.SubmissionModel.findOne({
            $or: [
                { 'UniqueId': UniqueId },
                { 'UniqueNumber': UniqueId }
            ]
        }, function (err, submission) {
            if (err) {
                res.json({ status: 201, message: err });
            }
            else {
                if (submission) {
                    if (!submission.UniqueNumber) {
                        var qstmno = submissionData.submission.submissionId;
                    }
                    else {
                        var qstmno = submission.UniqueNumber;
                    }
                    UniqueId = submission.UniqueId;
                    var dbFormData = submission.value;
                    var dbFormpageCompleted = submission.pageCompleted;
                    for (var submissionKey in submissionData.submission) {
                        for (var DBkey in dbFormData) {
                            if (submissionKey == DBkey) {
                                dbFormData[DBkey] = submissionData.submission[submissionKey];
                            }
                            else {
                                dbFormData[submissionKey] = submissionData.submission[submissionKey];
                            }
                        }
                    }
                    var pageStep = 0;
                    dbFormpageCompleted.forEach(function (element) {
                        if (submissionData.step == element.pageNo) {
                            pageStep++;
                        }
                    });
                    if (pageStep == 0) {
                        dbFormpageCompleted.push({ pageNo: submissionData.step, pageTitle: submissionData.pageTitle });
                    }
                    var Record = {
                        UniqueId: UniqueId,
                        UniqueNumber: qstmno,
                        value: dbFormData,
                        pageCompleted: dbFormpageCompleted
                    };
                    //console.log('Record==>', Record);
                    submission_1.SubmissionModel.update({ UniqueId: UniqueId }, Record, {
                        upsert: true
                    }, function (err, results) {
                        if (err) {
                            res.json({ error: err });
                        }
                        else {
                            res.json({ statusCode: 200, message: "Submission object saved successfully", data: submissionData.submission, UniqueId: UniqueId });
                        }
                    });
                }
                else {
                    dbFormPageStep = { pageNo: submissionData.step, pageTitle: submissionData.pageTitle };
                    var Record = {
                        UniqueId: UniqueId,
                        UniqueNumber: submissionData.submission.submissionId,
                        value: submissionData.submission,
                        pageCompleted: dbFormPageStep
                    };
                    submission_1.SubmissionModel.update({ UniqueId: UniqueId }, Record, {
                        upsert: true
                    }, function (err, results) {
                        if (err) {
                            res.json({ error: err });
                        }
                        else {
                            res.json({ statusCode: 200, message: "Submission saved successfully", data: submissionData.submission, UniqueId: UniqueId });
                        }
                    });
                }
            }
        });
    };
    Submission.prototype.get = function (req, res, next) {
        //implement logic to save to mongoose here
        //var SubmissionModel = new SubmissionModel();
        //console.log(req.query);
        var UniqueId = req.query.id;
        submission_1.SubmissionModel.findOne({
            $or: [
                { 'UniqueId': UniqueId },
                { 'UniqueNumber': UniqueId }
            ]
        }, function (err, submission) {
            if (err) {
                res.json({ status: 201, message: err });
            }
            else {
                console.log('submission==>', submission);
                res.json({ status: 200, message: "Submission object fetched successfully", data: submission });
            }
        });
    };
    
    return Submission;
}());
var post = new Submission().post;
exports.post = post;
var get = new Submission().get;
exports.get = get;
