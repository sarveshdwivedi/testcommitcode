"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mongoose = require("mongoose");
var schema = new mongoose.Schema({
    // schema model should match Document model
    UniqueId: { type: String },
    UniqueNumber: { type: String },
    value: {},
    pageCompleted: [{
            pageNo: Number,
            pageTitle: String
        }]
    //etc
});
var SubmissionModel = mongoose.model("submission", schema);
exports.SubmissionModel = SubmissionModel;
