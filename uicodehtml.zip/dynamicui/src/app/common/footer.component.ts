import { Component, OnInit } from '@angular/core';
import { contentJson } from '../core/config/content.json';

@Component({
  selector: 'app-footer',
  templateUrl: './view/footer/footer.component.html',
  styleUrls: ['./view/footer/footer.component.css']
})
export class FooterComponent implements OnInit {
  constructor(public content: contentJson) { }
  ngOnInit() {
  }
}
