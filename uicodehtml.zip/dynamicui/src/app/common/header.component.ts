import { Component, OnInit } from '@angular/core';
import { contentJson } from '../core/config/content.json';

@Component({
  selector: 'app-header',
  templateUrl: './view/header/header.component.html',
  styleUrls: ['./view/header/header.component.css']
})
export class HeaderComponent implements OnInit {
  constructor(public content: contentJson) { }
  ngOnInit() {}

}
