import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { PageNotFountComponent } from './pagenotfound.component';

const routes: Routes = [
    {
        path: '',
        loadChildren: './welcome/welcome.module#WelcomeModule'
    },
    {
        path: 'submission',
        loadChildren: './submission/submission.module#SubmissionModule'
    },
    {
        path: 'notfound',
        component: PageNotFountComponent
    },
    {
        path: '**',
        component: PageNotFountComponent
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {}