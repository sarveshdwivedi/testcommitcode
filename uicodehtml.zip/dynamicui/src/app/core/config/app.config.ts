import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';

@Injectable()
export class AppConfig {
    withoutLoginUrls: any = ['login'];
    GOOGLE_API_KEY : any = '';
    AUTH_URL : any = 'http://localhost:5000/authentication/';
    API_URL : any = 'http://localhost:5000/';
}