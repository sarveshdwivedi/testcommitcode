import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';

@Injectable()
export class contentJson {
    header: any = {
        'Logo': 'assets/images/Logo.svg',
        'logo': 'assets/images/logo.png',
        'HeaderTitle' : 'Title'
    };
    footerSection: any = {
        'title': '',
        'content': ''
    };
    footerSection2: any = {
        'title': '',
        'content': ''
    };
    footerSection3: any = {
        'title': 'Get Social',
        'facebookLogo': '<a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook fa-2x faa-pulse animated-hover"></i></a>'        
    };
    copyright: any = {
        'content': '© Copyright ',
    };
}