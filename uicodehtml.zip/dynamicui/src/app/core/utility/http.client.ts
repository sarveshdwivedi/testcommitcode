import { Injectable } from '@angular/core';
import { Http, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppConfig } from './../config/app.config';

@Injectable()
export class HttpClient {

  constructor(
    private http: Http,
    private router: Router,
    private config: AppConfig
  ) { }

  // createAuthorizationHeader(headers: Headers) {
  //   // Set to true if you need the website to include cookies in the requests sent
  //   // to the API (e.g. in case you use sessions)
  //   headers.append('Access-Control-Allow-Credentials', 'true');
  //   headers.append('Content-Type', 'application/json; charset=utf-8"');
  //   headers.append('Accept', 'application/json; charset=utf-8"');
  //   headers.append('x-access-token', 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnRfaWQiOiJjMWNkM2ZkMC1mZWQ1LTRiOTQtYjlkYy1mMDg2MGM5ZGJlNDMiLCJhZ2VuY3lfaWQiOjIyLCJjb250YWN0X2lkIjo5MTUsImlhdCI6MTUyNDU0NTM2NiwiZXhwIjoxNTI1MTUwMTY2fQ.WBam_AgcaBfDe3zbDcFpFIyUJA0KdgJ9VZhC58mTKBMQ0FUrKLnf4jk5NitatnAzTbaQcLiw_hbQd_UZ60HVwkGanSKWooB2N8IW5ym6H2Tutz5YYDmJQOOtrDwWAKvYO0sTeIKwUaoPtheDeXQA7Amh6VNbP7A3Aophr383KqQB5AYgRcnAGOAe5H_PqpIm2XxeQh2eajtzQS21kbpje4x3a2BbmLegzNxrwB_DvybSS9JJDUHPrRPeh8OK9HY-3FGH03jGfqKWNeL4h4aHw0IHU1nHfDhd-tnJEMBcLZmbcp5wuvSATnEBq13P90quYhav9vO2MHkz6H9bEmbDnw');
  //   // headers.append('Authorization', 'bearer ' + this.storage.get('erSuperAdminUserAuthToken'));
  // }

  get(url: any, data: any, fullUrl?: any) {
    fullUrl = fullUrl || false;
    const headers = new Headers();
    // this.createAuthorizationHeader(headers);
    const options: any = {
      headers: headers
    };
    const params: URLSearchParams = new URLSearchParams();
    Object.keys(data).map(function (key, index) {
      if (data[key] != '') {
        params.set(key, data[key]);
      }
    });
    options['search'] = params;
    const reqUrl = (fullUrl) ? fullUrl : this.config.API_URL + url;
    return this.http.get(reqUrl, options);
  }

  post(url: any, data: any, fullUrl?: any) {
    fullUrl = fullUrl || false;
    const headers: any = new Headers();
    // this.createAuthorizationHeader(headers);
    const reqUrl = (fullUrl) ? fullUrl : this.config.API_URL + url;
    // let options: any = {
    //   headers: headers
    // };
    const options: any = new RequestOptions({ headers: headers });
    return this.http.post(reqUrl, data, options);
  }

  extractData(res: any) {
    const body = res.json();
    return body.data || {};
  }

  handleError(error: any) {
    const errMsg: string = error.message ? error.message : error.toString();
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}