import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { AppConfig } from '../config/app.config';

@Injectable()
export class SubmissionService {
    data: any;
    constructor(
        private http: HttpClient,
        private config: AppConfig
    ) { }


    getSubmissionRecord(submissionData): Observable<any> {
        let params = new HttpParams().set("id", submissionData.UniqueId);
        const apiurl = this.config.API_URL;
        return this.http.get(apiurl, { params: params }).map(res => this.data = res);
    }

    // addSubmissionRecord method to call backend Agency post api for agent registration
    addSubmissionRecord(data: any): Observable<any> {
        const apiurl = this.config.API_URL;
        return this.http.post(apiurl, JSON.stringify(data)).map((res: any) => {
            if (res.statusCode === 200) {
                return { message: res.message, statusCode: res.statusCode };
            } else {
                return { message: res.message, statusCode: res.statusCode };
            }
        });
    }
}
