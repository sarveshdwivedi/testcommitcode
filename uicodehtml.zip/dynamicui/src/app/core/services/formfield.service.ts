import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpClient as httpCustom } from '../utility/http.client';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class FormFieldService {
  data: any;
  constructor(
    private http: HttpClient,
    private httpOld: httpCustom
  ) { }

  jsonuserdata(url): Observable<any> {
    return this.http.get(url)
      .map(res => this.data = res);
  }

  zipcodedata(url): Observable<any> {
    return this.http.get(url)
      .map(res => this.data = res);
  }

  getDatafromGoogleApi(url): Observable<any> {
    return this.httpOld.get('', {}, url).map((res: any) => {
      let body = res.json();
      return body;
    });
  }
}
