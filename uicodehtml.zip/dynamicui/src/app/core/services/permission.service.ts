import { Injectable } from '@angular/core';

@Injectable()
export class PermissionService {
  public obj: any;
  constructor() { }

  hasPermissionForBlogsEdit(){
      if(this.obj && this.obj['blogs']) return this.obj['blogs'].editPermission;
      else return false;
  }

  hasPermissionForBlogsAdd(){
      if(this.obj && this.obj['blogs']) return this.obj['blogs'].addPermission;
      else return false;
  }

  hasPermissionForBlogsDelete(){
      if(this.obj && this.obj['blogs']) return this.obj['blogs'].deletePermission;
      else return false;
}}
