import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfig } from '../config/app.config';

import {
  HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/do';
import { HttpErrorResponse } from '@angular/common/http';
import { RequestOptions } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class MyInterceptor implements HttpInterceptor {

  constructor(private router: Router,  
    private config: AppConfig) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const DevToken = localStorage.getItem('devToken') ? localStorage.getItem('devToken') : null;
   if (req.url == this.config.AUTH_URL) {
      var accessReq = req.clone({
        // headers: req.headers.set('Content-Type', 'application/json; charset=utf-8')
        //Comented for testing
        headers: req.headers.set('x-access-token', 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9').set('Content-Type', 'application/json; charset=utf-8')
      });
    } 
    else {
      var accessReq = req.clone({
        headers: req.headers.set('x-access-token', 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9').set('Content-Type', 'application/json; charset=utf-8')
      });
    }
    return next.handle(accessReq);
  }

}