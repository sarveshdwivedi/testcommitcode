import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { HttpClient } from '../utility/http.client';
import { AppConfig } from '../config/app.config';


@Injectable()
export class AuthService {
    redirectUrl: string;
    isLoggedIn = false;

    constructor(
        private http: HttpClient,
        private config: AppConfig
    ) { }

    logout(): void {
        this.isLoggedIn = false;
    }
}
