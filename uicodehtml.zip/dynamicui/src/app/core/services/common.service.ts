import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { AppConfig } from '../config/app.config';

@Injectable()
export class CommonService {
  data: any;
  constructor(
    private http: HttpClient,
    private config: AppConfig
  ) { }


  getRecordByAPI(api: any): Observable<any> {
    var apiurl;
    apiurl = this.config.API_URL + api;

    return this.http.get(apiurl).map(res => this.data = res).catch((e: any) => {
      return Observable.of(e);
    });
  }

  getRecord(data: any): Observable<any> {
    const apiurl = this.config.API_URL + this.config.API_URL;
    return this.http.post(apiurl, JSON.stringify(data)).map(res => this.data = res).catch((e: any) => {
      return Observable.of(e);
    });
  }

  updateRecord(data: any, refId: any, submissionId: any): Observable<any> {
    const apiurl = this.config.API_URL + this.config.API_URL + refId + '/' + submissionId;
    return this.http.put(apiurl, JSON.stringify(data)).map(res => this.data = res).catch((e: any) => {
      return Observable.of(e);
    });
  }



 

  getRecordByAPIParameters(bindApi: any, query: any): Observable<any> {
    let params = new HttpParams().set("stateName", query.stateName).set("effectiveDate", query.EffectiveDate);
    const apiurl = this.config.API_URL + bindApi;
    return this.http.get(apiurl, { params: params }).map(res => this.data = res).catch((e: any) => {
      return Observable.of(e);
    });
  }


 



  getAuthenticateToken(): Observable<any> {
    var apiurl;
    var requestDom;
    requestDom = this.config.API_URL;
    apiurl = this.config.API_URL + this.config.API_URL;
    return this.http.post(apiurl, requestDom).map(res => this.data = res).catch((e: any) => {
      return Observable.of(e);
    });
  }
}
