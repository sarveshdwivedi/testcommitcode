import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SubmissionComponent } from './component/submission.component';
import { CommonService } from '../core/services/common.service';
import { FormFieldService } from '../core/services/formfield.service';


const routes: Routes = [
    { path: '', component: SubmissionComponent }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SubmissionRoutingModule {}