import { Component, OnInit, ElementRef, NgZone, ViewChild } from '@angular/core';
import { CommonService } from '../../core/services/common.service';
import { FormFieldService } from '../../core/services/formfield.service';
import { SubmissionService } from '../../core/services/submission.service';
import { AppConfig } from '../../core/config/app.config';
import { trigger, state, style, animate, transition, keyframes, query, stagger } from '@angular/animations';
import { ParamMap, Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { } from '@types/googlemaps';
import { MapsAPILoader } from '@agm/core';
declare var google: any;

@Component({
  selector: 'app-submission',
  templateUrl: './submission.component.html',
  styleUrls: ['./submission.component.css'],
  providers: [
    FormFieldService,
    CommonService,
    SubmissionService,
    AppConfig
  ]
})

export class SubmissionComponent implements OnInit {
  public currentdate: any;
  public minDateValue: any;
  public maxDateValue: any;
  public formFieldArrays: any = [];
  public step = 0;
  public stepData: any;
  public UniqueId: any;
  public LoaderClass: any = 'hidden'

  public stepHeadingList: any = [];
  public apiList: any = [];
  public panelAPIList: any = [];
  public uniqueApiList: any = [];
  public StateName: any;
  public ZipCode: any;
  public City: any;
  public MailingState: any;
  public MailingCity: any;
  public MailingAddress: any;
  public MailingZipCode: any;
  public classCode: any;
  public BusinessAddress: any;
  public effectiveDate: any;
  public businessAdd: any = [];
  public AddressSuggestion: any = [];
  public AddressAutoSuggestion: any = [];
  public submissionFormData: any = [];
  public codeDetailsArray: any = [];
  public ratePlanPayment: any = {};
  public toggleHtml: any = '<i class="glyphicon glyphicon-chevron-down"></i> Show Details';
  public toggleDetailTab: boolean = false;
  public display: boolean = false;
  public isNextStepDisabled: boolean = false;
  public isNextStepDisable: boolean = false;
  public loaderMessage: any;
  public errmsg: any;

  public isChecked: boolean = false;
  public isLiable: boolean = false;
  public autocompleteData: any = [];
  public InvalidBusinesStateMessg: any;
  public InvalidMailingStateMessg: any;
  public isBusinessStateValid: boolean = false;
  public isDialogOpen: boolean = false;

  @ViewChild('searchField', { read: ElementRef })
  private searchFieldEmentRef: ElementRef;

  @ViewChild("searchMailingAdd", { read: ElementRef })
  public searchMailingElmRef: ElementRef;

  constructor(
    private FormField: FormFieldService,
    private Common: CommonService,
    private Submission: SubmissionService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private Config: AppConfig,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone
  ) {

  }

  // Lifecycle hook that is called after data-bound properties of a directive are initialized.
  ngOnInit() {
    this.currentdate = moment().add(2, 'days').format('YYYY-MM-DD');
    this.minDateValue = new Date();
    this.minDateValue = new Date();
    this.minDateValue.setDate(this.minDateValue.getDate() + 1);
    this.maxDateValue = new Date(moment(this.minDateValue, 'YYYY-MM-DD').add(29, 'days').format());
    this.Common.getAuthenticateToken().subscribe((result: any) => {
      localStorage.setItem('devToken', result.token);
    });

    //const url = './assets/configFiles/submissionFields.json';
    const url = ['./assets/configFiles/submissionFields.json'];
    var rand = url[Math.floor(Math.random() * url.length)];

    this.FormField.jsonuserdata(rand)
      .subscribe(data => {
        this.formFieldArrays = data;
        this.stepData = data[0];
        this.getStepHeadingList();
        this.getListBindProperty();
      });

    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.UniqueId = params['id'];
        this.getBackSubmissionFormData(this.UniqueId);
      }

    });
  }

  // Get google autocomplete address for business address field
  googleBusinessAddress() {

    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchFieldEmentRef.nativeElement, {
        types: ["address"],
        componentRestrictions: { country: "us" }
      });
      autocomplete.addListener("place_changed", () => {
        this.InvalidBusinesStateMessg = "";
        this.isBusinessStateValid = false;
        this.ngZone.run(() => {
          //get the place result
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          this.BusinessAddress = place.formatted_address;
          for (let i = 0; i < place.address_components.length; i += 1) {
            let addressObj = place.address_components[i];
            for (let j = 0; j < addressObj.types.length; j += 1) {
              if (addressObj.types[j] === 'postal_code') {
                this.ZipCode = addressObj.short_name;
              }
            }
            for (var k = 0; k < addressObj.types.length; k += 1) {
              if (addressObj.types[k] === 'administrative_area_level_1') {
                this.StateName = addressObj.short_name;
              }
            }
            for (var l = 0; l < addressObj.types.length; l += 1) {
              if (addressObj.types[l] === 'locality') {
                this.City = addressObj.short_name;
              }
            }

          }

          this.changeFeildInputValue("BusinessAddress");


        });
      });
    });
  }
  // Get google autocomplete address for mailing address field
  googleMailingAddress() {
    this.mapsAPILoader.load().then(() => {
      let autocomplete = new google.maps.places.Autocomplete(this.searchMailingElmRef.nativeElement, {
        types: ["address"],
        componentRestrictions: { country: "us" }
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          this.MailingAddress = place.formatted_address;
          for (let i = 0; i < place.address_components.length; i += 1) {
            let addressObj = place.address_components[i];
            for (let j = 0; j < addressObj.types.length; j += 1) {
              if (addressObj.types[j] === 'postal_code') {
                this.MailingZipCode = addressObj.short_name;
              }
            }
            for (var k = 0; k < addressObj.types.length; k += 1) {
              if (addressObj.types[k] === 'administrative_area_level_1') {
                this.MailingState = addressObj.short_name;
              }
            }
            for (var l = 0; l < addressObj.types.length; l += 1) {
              if (addressObj.types[l] === 'locality') {
                this.MailingCity = addressObj.short_name;
              }
            }

          }

          this.changeFeildInputValue("MailingAddress");
        });
      });
    });
  }

  // Get all step page header title list for header progress bar
  getStepHeadingList() {
    if (this.formFieldArrays.length > 0) {
      for (let i = 0; i < this.formFieldArrays.length; i++) {
        for (let j = 0; j < this.formFieldArrays[i].step.length; j++) {
          if (this.formFieldArrays[i].step[j].type === 'pageHeading') {
            this.stepHeadingList.push(this.formFieldArrays[i].step[j].title);
            //this.stepHeadingList.splice(i, 1);
          }

        }
      }
    }
  }

  //Get all list of bind property/api
  getListBindProperty() {
    if (this.formFieldArrays.length > 0) {
      for (let i = 0; i < this.formFieldArrays.length; i++) {
        for (let j = 0; j < this.formFieldArrays[i].step.length; j++) {
          if (this.formFieldArrays[i].step[j].type === 'boxHeading') {
            for (let k = 0; k < this.formFieldArrays[i].step[j].fields.length; k++) {
              if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'dropdown') {
                this.apiList.push(this.formFieldArrays[i].step[j].fields[k].bindProperty);
              } else {
                if (this.formFieldArrays[i].step[j].fields[k].fieldSet) {
                  for (let h = 0; h < this.formFieldArrays[i].step[j].fields[k].fieldSet.length; h++) {
                    if (this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldType == 'dropdown') {
                      this.apiList.push(this.formFieldArrays[i].step[j].fields[k].fieldSet[h].bindProperty);
                    } else if (this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldType == 'PIPlan') {
                      for (let t = 0; t < this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldSet.length; t++) {
                        this.apiList.push(this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldSet[t].bindProperty);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    this.uniqueApiList = Array.from(new Set(this.apiList));
  }

  //call function on click on next button
  nextStep(btn: any, value: any) {
    if (btn === 'nxt' && this.formFieldArrays.length > this.step) {
      this.step++;
    } else {

      this.step--;
    }
    this.stepData = this.formFieldArrays[this.step];

  }

  checkValue(event) {
    if (event == 'true') {
      this.isNextStepDisabled = true
    } else {
      this.isNextStepDisabled = false;

    }
  }

  onChange(value) {
    if (value == 'true') {
      this.isLiable = true;
      this.isNextStepDisabled = this.isNextStepDisabled;
    } else {
      this.isLiable = false;
    }
  }






  //call function for show/hide popup dialog box
  showDialog() {
    this.display = true;
  }

  //call function to save form each step data on mongoDb collection
  submitSubmissionForm(value: any, step: any, Id: any) {
    this.isDialogOpen = false;
    localStorage.removeItem('d');




    var pageHeading = value.pageHeading
    delete value.pageHeading;
    const submissionData = {
      submission: value,
      step: step,
      pageTitle: pageHeading,
      UniqueId: Id
    };

    this.Submission.addSubmissionRecord(submissionData).subscribe((result: any) => {

      if (sessionStorage.getItem("UniqueId") != null) {
        this.UniqueId = sessionStorage.getItem('UniqueId');
      } else {
        this.UniqueId = result.UniqueId;
        sessionStorage.setItem("UniqueId", this.UniqueId);
      }
      this.getNxtSubmissionFormData(this.UniqueId);
    });


  }



  callOnchangeHandler(Op) {

    this.OpSelectedArray = Op;
    var ops = [];
    this.OpSelectedArray.forEach(element => {

      if (element[0] == true) {
        this.OperationsSelectedArray.push(parseInt(element[1]));
        this.OperationsSelectedArray = this.OperationsSelectedArray.filter((v, i, a) => a.indexOf(v) === i);
      } else if (element[0] == false) {
        for (var i = 0; i < this.OperationsSelectedArray.length; i++) {
          if (this.OperationsSelectedArray[i] == element[1]) {
            this.OperationsSelectedArray.splice(i, 1);
          }
        }
      }
    });
    if (this.OperationsSelectedArray.length > 0) {
      this.isNextStepDisabled = false
    } else {
      this.isNextStepDisabled = true
    }
  }

  changeHandler(fieldID, event) {
    if (event == true) {
      for (let i = 0; i < this.stepData.step[1].fields.length; i++) {
        if (this.stepData.step[1].fields[i].fieldType === "AddressBoxContent") {
          for (let j = 0; j < this.stepData.step[1].fields[i].fieldSet.length; j++) {
            if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingCity") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.City;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingState") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.StateName;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingZipCode") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.ZipCode;
            }
          }
        } else if (this.stepData.step[1].fields[i].fieldType === "address") {
          if (this.stepData.step[1].fields[i].fieldname === "MailingAddress") {
            this.stepData.step[1].fields[i].bindValue = this.BusinessAddress;
          }
        }
      }
    } else {
      for (let i = 0; i < this.stepData.step[1].fields.length; i++) {
        if (this.stepData.step[1].fields[i].fieldType === "AddressBoxContent") {
          for (let j = 0; j < this.stepData.step[1].fields[i].fieldSet.length; j++) {
            if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingCity") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = '';
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingState") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = '';
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingZipCode") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = '';
            }
          }
        } else if (this.stepData.step[1].fields[i].fieldType === "address") {
          if (this.stepData.step[1].fields[i].fieldname === "MailingAddress") {
            this.stepData.step[1].fields[i].bindValue = '';
          }
        }
      }
    }
  }


  // call function to get back step form data and bind value in fields
  getBackSubmissionFormData(UniqueId: any) {
    const submissionData = {
      UniqueId: UniqueId || sessionStorage.getItem('UniqueId')
    };

    var formfieldValue;
    this.Submission.getSubmissionRecord(submissionData).subscribe((result: any) => {
      if (result.status == 200) {
        this.submissionFormData = result.data.value;

        if (this.UnderwritingQuestions.length == 0) {
          this.callUnderwritingQuestionsHandler(this.submissionFormData.classCode);
        }
        if (this.AgencyId == '' && this.Contactid == '') {
          this.AgencyId = this.submissionFormData.AgencyId;
          this.Contactid = this.submissionFormData.Contactid;
        }
        for (let i = 0; i < this.formFieldArrays.length; i++) {
          for (let j = 0; j < this.formFieldArrays[i].step.length; j++) {
            if (this.formFieldArrays[i].step[j].type === 'boxHeading') {
              for (let k = 0; k < this.formFieldArrays[i].step[j].fields.length; k++) {
                if (this.formFieldArrays[i].step[j].fields[k].fieldSet) {
                  for (let h = 0; h < this.formFieldArrays[i].step[j].fields[k].fieldSet.length; h++) {
                    this.formFieldArrays[i].step[j].fields[k].fieldSet[h].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldname];
                  }
                } else if (this.formFieldArrays[i].step[j].fields[k].radioSet) {
                  for (let h = 0; h < this.formFieldArrays[i].step[j].fields[k].radioSet.length; h++) {
                    this.formFieldArrays[i].step[j].fields[k].radioSet[h].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].radioSet[h].fieldname];
                  }
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'checkbox') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] || true;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'date') {
                  this.currentdate = '';
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'text') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'email' || this.formFieldArrays[i].step[j].fields[k].fieldType == 'phonenumber') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname];
                }
                else {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
              }
            }
          }
        }
        if (this.step == 1) {
          this.googleBusinessAddress();
          this.googleMailingAddress();
        }
      }
    });
  }

  // call function to get next step form data and bind value in fields
  getNxtSubmissionFormData(UniqueId: any) {
    const submissionData = {
      UniqueId: UniqueId || sessionStorage.getItem('UniqueId')
    };
    var formfieldValue;
    this.Submission.getSubmissionRecord(submissionData).subscribe((result: any) => {
      if (result.status == 200) {
        this.submissionFormData = result.data.value;

        for (let i = 0; i < this.formFieldArrays.length; i++) {
          for (let j = 0; j < this.formFieldArrays[i].step.length; j++) {
            if (this.formFieldArrays[i].step[j].type === 'boxHeading') {
              for (let k = 0; k < this.formFieldArrays[i].step[j].fields.length; k++) {
                if (this.formFieldArrays[i].step[j].fields[k].fieldSet) {
                  for (let h = 0; h < this.formFieldArrays[i].step[j].fields[k].fieldSet.length; h++) {
                    this.formFieldArrays[i].step[j].fields[k].fieldSet[h].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldSet[h].fieldname];
                  }
                } else if (this.formFieldArrays[i].step[j].fields[k].radioSet) {
                  for (let h = 0; h < this.formFieldArrays[i].step[j].fields[k].radioSet.length; h++) {
                    this.formFieldArrays[i].step[j].fields[k].radioSet[h].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].radioSet[h].fieldname];
                  }
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'checkbox') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] || true;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'date') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'text') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
                else if (this.formFieldArrays[i].step[j].fields[k].fieldType == 'email' || this.formFieldArrays[i].step[j].fields[k].fieldType == 'phonenumber') {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname];
                }
                else {
                  this.formFieldArrays[i].step[j].fields[k].bindValue = result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] ? result.data.value[this.formFieldArrays[i].step[j].fields[k].fieldname] : this.formFieldArrays[i].step[j].fields[k].bindValue;
                }
              }
            }
          }
        }
        if (this.step == 1) {
          this.googleBusinessAddress();
          this.googleMailingAddress();
        }
      }
    });
  }


  changeFeildInputValue(fieldName) {
    if (fieldName == "MailingAddress") {
      for (let i = 0; i < this.stepData.step[1].fields.length; i++) {
        if (this.stepData.step[1].fields[i].fieldType === "AddressBoxContent") {
          for (let j = 0; j < this.stepData.step[1].fields[i].fieldSet.length; j++) {
            if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingCity") {

              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.MailingCity;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingState") {

              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.MailingState;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "MailingZipCode") {

              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.MailingZipCode;
            }
          }
        }
        else if (this.stepData.step[1].fields[i].fieldType === "MailingAddress") {
          if (this.stepData.step[1].fields[i].fieldname == "MailingAddress") {
            this.stepData.step[1].fields[i].bindValue = this.MailingAddress.split(',')[0];
          }
        }
      }
    } else {
      for (let i = 0; i < this.stepData.step[1].fields.length; i++) {
        if (this.stepData.step[1].fields[i].fieldType === "AddressBoxContent") {
          for (let j = 0; j < this.stepData.step[1].fields[i].fieldSet.length; j++) {
            if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "City") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.City;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "StateName") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.StateName;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "ZipCode") {
              this.stepData.step[1].fields[i].fieldSet[j].bindValue = this.ZipCode;
            }
          }
        }
        else if (this.stepData.step[1].fields[i].fieldType === "BusinessAddress") {
          if (this.stepData.step[1].fields[i].fieldname == "BusinessAddress") {
            this.stepData.step[1].fields[i].bindValue = this.BusinessAddress.split(',')[0];
          }
        }
      }
    }
  }

  // call function to toggle div on price indication page for additional information
  toggleClassfn() {
    if (this.toggleDetailTab) {
      this.toggleDetailTab = false;
      this.toggleHtml = '<i class="glyphicon glyphicon-chevron-down"></i> Show Details';
    } else {
      this.toggleDetailTab = true;
      this.toggleHtml = '<i class="glyphicon glyphicon-chevron-up"></i> Hide Details';
    }
  }




  // on checkbox select busines address data gets copied
  selectCheckbox($event) {
    if ($event.target.checked == true) {
      for (let i = 0; i < this.stepData.step[1].fields.length; i++) {
        if (this.stepData.step[1].fields[i].fieldType === "AddressBoxContent") {
          for (let j = 0; j < this.stepData.step[1].fields[i].fieldSet.length; j++) {
            if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "City") {
              this.MailingCity = this.stepData.step[1].fields[i].fieldSet[j].bindValue;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "StateName") {
              this.MailingState = this.stepData.step[1].fields[i].fieldSet[j].bindValue;
            } else if (this.stepData.step[1].fields[i].fieldSet[j].fieldname == "ZipCode") {
              this.MailingZipCode = this.stepData.step[1].fields[i].fieldSet[j].bindValue;
            }
          }
        }
        else if (this.stepData.step[1].fields[i].fieldType === "BusinessAddress") {
          if (this.stepData.step[1].fields[i].fieldname == "BusinessAddress") {
            this.MailingAddress = this.stepData.step[1].fields[i].bindValue;
          }
        }
      }

      setTimeout(() => {
        this.changeFeildInputValue("MailingAddress");
      }, 500)

    } else {
      this.formFieldArrays[1].step[1].fields[4].bindValue = '';
      this.formFieldArrays[1].step[1].fields[5].fieldSet[0].bindValue = '';
      this.formFieldArrays[1].step[1].fields[5].fieldSet[1].bindValue = '';
      this.formFieldArrays[1].step[1].fields[5].fieldSet[2].bindValue = '';
    }
  }


  printComponent(cmpName) {
    let printContents = document.getElementById(cmpName).innerHTML;
    let originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;

    window.print();

    document.body.innerHTML = originalContents;
  }

  confirmationPopup() {
    this.isDialogOpen = true;
  }
  cancel() {
    this.isDialogOpen = false;
  }
}


