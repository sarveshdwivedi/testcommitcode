import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubmissionRoutingModule } from '../submission/submission-routing.module';
import { SubmissionComponent } from '../submission/component/submission.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {CalendarModule} from 'primeng/calendar';
import {InputMaskModule} from 'primeng/inputmask';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {TooltipModule} from 'primeng/tooltip';
import {DialogModule} from 'primeng/dialog';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

@NgModule({
    imports: [
        CommonModule,
        SubmissionRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        CalendarModule,
        InputMaskModule,
        AutoCompleteModule,
        TooltipModule,
        DialogModule,
        Ng4LoadingSpinnerModule.forRoot()
    ],
    declarations: [SubmissionComponent],
    providers: []
})
export class SubmissionModule {}