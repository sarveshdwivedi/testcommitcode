import { Component, OnInit, EventEmitter } from '@angular/core';
import { ParamMap, Router, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'Not-Found',
    template: `
    <div class="not-found-container">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-6 pull-right">
                <div class="not-found-content themeTxtColor">
                    <h2>Ooops...</h2>
                    <p>test </p>
                    <button type="button" class="rounded-btn btn btn-default wizard-button-next next-btn pull-right">Back to Home</button>
                </div>
            </div>
        </div>
    </div>
    </div>
    `,
    styles: []
})
export class PageNotFountComponent {
    public Id: any;
    constructor(
        private route: ActivatedRoute,
        private router: Router,
    ) { }
    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            this.Id = params['id'];
        });
    }
}